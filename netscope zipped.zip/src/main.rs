mod collector;
mod engine;
mod ui;

use std::{
    collections::HashMap,
    io::stdout,
    thread,
    time::Duration,
};

use collector::{
    collect_per_process_usage,
    discover_processes,
    discover_socket_inodes,
    filter_by_name,
    filter_idle,
    read_key,
    KeyAction,
};

use engine::Engine;

use ui::{
    App,
    SortMode,
    render_ui,
};

use crossterm::{
    cursor::{Hide, Show},
    execute,
    terminal::{
        disable_raw_mode,
        enable_raw_mode,
        EnterAlternateScreen,
        LeaveAlternateScreen,
    },
};

use ratatui::{
    backend::CrosstermBackend,
    Terminal,
};
